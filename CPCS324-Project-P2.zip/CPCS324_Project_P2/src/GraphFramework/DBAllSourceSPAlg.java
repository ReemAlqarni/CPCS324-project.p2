package GraphFramework;

// This class represents the implementation of the Dijkstra-based shortest path algorithm for
//computing the shortest path from each vertex to the rest of the vertices.
public class DBAllSourceSPAlg extends ShortestPathAlgorithms{

    // This class used to call ComputeDijkstraBasedSPAlg method
    public DBAllSourceSPAlg(){
    }

    public void ComputeDijkstraBasedSPAlg() {
        int[] nValues = {2000, 3000, 4000, 5000, 6000};
        int[] mValues = {10000, 15000, 20000, 25000, 30000};
        int[] runtimes = new int[nValues.length];
        int[] theoryRuntimes = new int[nValues.length];

        System.out.println("Table 1: Runtime Table");
        System.out.println("\t n \t\t Running Time \t\t Expected Theoretical Time");
        for (int i = 0; i < nValues.length; i++) {
            int n = nValues[i];
            int m = mValues[i];
            Graph networkTopology = new Graph(n, m, true); // Create An Object of Graph as networkTopology
            networkTopology.makeGraph(n, m); // Access makeGraph Method in Graph Class
            SingleSourceSPAlg dijkstra = new SingleSourceSPAlg(networkTopology); // Create DijkstraAlg object to use Dijkstra algorithm
            long startTime = System.currentTimeMillis(); // Store the time before invoking the algorithm
            dijkstra.computeDijkstraAlg(networkTopology);
            long finishTime = System.currentTimeMillis(); // Store the time after invoking the algorithm
            runtimes[i] = (int) (finishTime - startTime);
            theoryRuntimes[i] = (int) Math.round(n / 1000.0 * m / 1000.0 * Math.log(n / 1000.0));
            System.out.println("\t " + n + " \t\t " + runtimes[i] + " \t\t " + theoryRuntimes[i]);
        }

        System.out.println("\n");
        System.out.println("Table 2: Runtime Ratio Table");
        System.out.println("\t  \t\t\t    Ratio of Running Time \t\t Ratio of Expected Theoretical Time");
        for (int j = 1; j < runtimes.length; j++) {
            System.out.println("\t " + nValues[j] + "/" + nValues[j - 1] + " \t\t\t\t\t\t " + runtimes[j] + "/" + runtimes[j - 1] + " \t\t " + theoryRuntimes[j] + "/" + theoryRuntimes[j - 1]);
        }
    }

}
