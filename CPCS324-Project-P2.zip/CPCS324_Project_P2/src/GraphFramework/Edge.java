
package GraphFramework;

public class Edge {

	// Data Fields
	int weight;
	Vertex source;
	Vertex target;
	Vertex parent;

	public Edge() {
		source = new Vertex(); // create new source
		target = new Vertex(); // create new target
		parent = new Vertex(); // create new parent
	}

	public Edge(Vertex source, Vertex target, int weight) {
		this.source = source;
		this.target = target;
		this.weight = weight;
		parent = new Vertex();
	}

//	public void displayInfo() {
//		// Display information about the edge, including source, target, and weight
//		System.out.println("Edge: " + source.label + " -> " + target.label);
//		System.out.println("Weight: " + weight);
//	}

}
