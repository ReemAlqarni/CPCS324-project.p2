package GraphFramework;

import AirFreighApp.AFRouteMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Graph {

    // Data Fields
    public int verticesNO; // # of Vertices
    int edgeNO; // # of Edges
    Boolean isDigraph; // is Graph directed or not
    public Vertex[] vertices; // Array of Vertices
    Graph map;

    public Graph(int verticesNO, int edgeNO, boolean isDigraph) {
        this.verticesNO = verticesNO;
        this.edgeNO = edgeNO;
        this.isDigraph = isDigraph;
        this.vertices = new Vertex[verticesNO];
    }

    // ---Constructor to use it for Read Graph from File Function.---///

    public Graph() {
    }

    /**
     * Creates a new vertex with the given label.
     *
     * @param label The label of the vertex.
     * @return The created vertex.
     */
    public Vertex createVertex(int label) {
        return new Vertex(label);
    }

    /**
     * Creates a new edge between the given source and target vertices with the given weight.
     *
     * @param source The source vertex.
     * @param target The target vertex.
     * @param weight The weight of the edge.
     * @return The created edge.
     */
    public Edge createEdge(Vertex source, Vertex target, int weight) {
        return new Edge(source, target, weight);
    }

    /**
     * Adds an edge between the vertices with the given labels and the given weight.
     *
     * @param v      The label of the source vertex.
     * @param u      The label of the target vertex.
     * @param weight The weight of the edge.
     */
    public void addEdge(Vertex v, Vertex u, int weight) {

        Graph map = new AFRouteMap();


        // This eliminates duplicates for the source vertex
        if (vertices[v.label] == null) {
            verticesNO++; // Increment the number of vertices first to avoid size problems
            vertices[v.label] = map.createVertex(v.label); // Create a new source vertex in the array of vertices
        }

        // This eliminates duplicates for the target vertex
        if (vertices[u.label] == null) {
            verticesNO++; // Increment the number of vertices first to avoid size problems
            vertices[u.label] = map.createVertex(u.label); // Create a new target vertex in the array of vertices
        }

        // Create a new edge
        Edge newEdge = map.createEdge(vertices[v.label], vertices[u.label], weight);
        edgeNO++; // Increase the number of edges

        // Access the vertex's adjacency list and add the edge with its weight
        vertices[v.label].adjList.add(newEdge);

        // If the graph is undirected, add the opposite edge
        if (!isDigraph) {

            // Add the opposite edge (undirected)
            newEdge = map.createEdge(vertices[u.label], vertices[v.label], weight);
            edgeNO++; // Increase the number of edges

            // Access the vertex's adjacency list and add the edge with its weight
            vertices[u.label].adjList.add(newEdge);
        }

    }

    /**
     * Reads the graph from a file.
     *
     * @param fileName The name of the file.
     * @throws FileNotFoundException If the file is not found.
     */
    public void readGraphFromFile(File fileName) throws FileNotFoundException {

        Scanner input = new Scanner(fileName); // Scanner to read from file

        String typeofGraph = input.nextLine(); // Is the graph directed or not?
        if (typeofGraph.equalsIgnoreCase("digraph 0")) {
            isDigraph = false; // 0 == undirected graph
        } else if (typeofGraph.equalsIgnoreCase("digraph 1")) {
            isDigraph = true; // 1 == directed graph
        }

        int totalNumberOfVertices = input.nextInt(); // Read the total number of vertices (second line)
        int totalNumberOfEdge = input.nextInt(); // Read the total number of edges (still second line)

        if (!isDigraph) {
            totalNumberOfEdge *= 2; // Double the number of edges for undirected graphs
        }

        vertices = new Vertex[totalNumberOfVertices]; // Initialize the array of vertices

        while (edgeNO < totalNumberOfEdge) {
            int sourceLabel = input.next().charAt(0) - 65;
            int destinationLabel = input.next().charAt(0) - 65;
            int weight = input.nextInt();

            Vertex source = createVertex(sourceLabel);
            Vertex destination = createVertex(destinationLabel);

            addEdge(source, destination, weight);
        } // End of while-loop


        input.close();
    }

    /**
     * Creates a random graph with the specified number of vertices and edges.
     *
     * @param verticesNO The number of vertices.
     * @param edgeNO     The number of edges.
     */
    public void makeGraph(int verticesNO, int edgeNO) {

        // Store all vertices accordingly
        for (int i = 0; i < verticesNO; i++) {
            vertices[i] = new Vertex(i);
        }

        // Store edges respectively to make sure all vertices are connected ( (|V|-1) = #E )
        for (int i = 0; i < verticesNO - 1; i++) {
            // Vertex u, Vertex v, random edge weight
            addEdge(vertices[i], vertices[i + 1], (int) (1 + Math.random() * 10));
        }

        int i = 0;
        // Add remaining edges randomly: edgeNO - (|V|-1)
        while (i < (edgeNO - (verticesNO - 1))) {
            int vertexU = (int) (Math.random() * verticesNO);
            int vertexV = (int) (Math.random() * verticesNO);

            // Avoid vertices if they are self-looped
            if (vertexU == vertexV) {
                continue; // Skip the loop (increment is skipped as well) and get new random vertices
            }

            // Avoid duplicate edge with the same source and target
            for (int j = 0; j < vertices[vertexU].adjList.size(); j++) {
                if (vertices[vertexU].adjList.get(j).target.label != vertexV) {
                    break; // Break out of the loop if vertexU and vertexV are not an edge
                }
            }

            // If there was no self-loop vertex and no existing edge, add a new edge and increment
            addEdge(vertices[vertexU], vertices[vertexV], (int) (1 + Math.random() * 10));
            i++;

        } // End of while-loop
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Graph Information:\n");
        sb.append("Number of Vertices: ").append(verticesNO).append("\n");
        sb.append("Number of Edges: ").append(edgeNO).append("\n");
        sb.append("Directed: ").append(isDigraph).append("\n");

        for (int i = 0; i < verticesNO; i++) {
            sb.append("\nVertex ").append(i).append(":\n");
            Vertex vertex = vertices[i];
            sb.append(vertex.displayInfo()).append("\n");
            sb.append("Adjacent Vertices: ");
            for (Edge edge : vertex.adjList) {
                sb.append(edge.target.label).append(" ");
            }
            sb.append("\n");
        }

        return sb.toString();
    }


} // end of Class
