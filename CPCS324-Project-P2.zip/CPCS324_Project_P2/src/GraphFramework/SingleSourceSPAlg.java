package GraphFramework;
import java.util.Iterator;

public class SingleSourceSPAlg extends ShortestPathAlgorithms{

	// Data Fields
	int[] distance; // Hold the shortest distance from source to each vertex
	String[] path; // Hold the vertices path from the source to the vertex
	Graph graph;
	int infinity = Integer.MAX_VALUE; // Hold max value

	public SingleSourceSPAlg(Graph graph) {
		this.graph = graph;
	}

	public void computeDijkstraAlg(Graph graph) {

		// Initialize distance array and path array
		distance = new int[graph.vertices.length];
		path = new String[graph.vertices.length];

		// Set all distances to infinity
		for (int i = 0; i < graph.vertices.length; i++) {
			distance[i] = infinity;
		}

		// Set distance of source vertex to 0
		distance[0] = 0;
		Vertex src = graph.vertices[0].adjList.get(0).source; // Get the source Vertex
		path[0] = src.displayInfo(); // Set the path of the source vertex

		// Iterate through all vertices
		for (int i = 0; i < graph.vertices.length - 1; i++) {
			// Pick the vertex with the minimum distance among the unvisited vertices
			int u = minDistance(distance);
			graph.vertices[u].isVisited = true; // Mark the picked vertex as visited

			// Iterate through the neighbors of the picked vertex
			Iterator<Edge> iterate = graph.vertices[u].adjList.iterator();
			while (iterate.hasNext()) {
				Edge edge = iterate.next();

				// Continue only if the neighbor vertex is not visited, has a valid weight,
				// and is not the source vertex itself
				if (!graph.vertices[edge.target.label].isVisited && edge.weight != infinity && edge.weight != 0) {
					// Calculate the new distance from the source vertex to the neighbor vertex
					int newDistance = distance[u] + edge.weight;

					// Update the distance and path arrays if the new distance is smaller than the current distance
					if (newDistance < distance[edge.target.label]) {
						distance[edge.target.label] = newDistance;
						path[edge.target.label] = path[u] + " – " + edge.target.displayInfo();
					}
				}
			}
		}
	}

	// Find the vertex with the minimum distance among the unvisited vertices
	public int minDistance(int[] smallestDistance) {
		int u = 0;
		int minDistance = Integer.MAX_VALUE;

		// Loop through all vertices
		for (int i = 0; i < graph.vertices.length; i++) {
			// The vertex must be not visited and its distance is smaller than the minimum distance
			if (!graph.vertices[i].isVisited && smallestDistance[i] < minDistance) {
				minDistance = smallestDistance[i];
				u = i; // Minimum vertex index
			}
		}
		return u;
	}

	// Print the result of the Dijkstra's algorithm
	public void printResult() {
		String routerName = String.valueOf((char) (graph.vertices[0].label + 65));
		System.out.println("The starting point location is " + routerName);
		System.out.println("\nThe routes from location " + routerName + " to the rest of the locations are:");

		// Start loop from 1 to ignore the first vertex
		for (int i = 1; i < graph.verticesNO; i++) {
			System.out.println("\n" + path[i] + "; route length: " + distance[i]);
		}
	}
}
