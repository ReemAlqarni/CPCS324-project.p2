package GraphFramework;

import java.util.LinkedList;

public class Vertex {

	// Data Fields
	public int label; // Name of this Vertex
	Boolean isVisited;
	LinkedList<Edge> adjList; // The AdjList of this Vertex

	public Vertex() {
		adjList = new LinkedList<>();
	}

	public Vertex(int label) {
		this.label = label;
		this.isVisited = false;
		adjList = new LinkedList<>();
	}

	// Methods

	/**
	 * Displays information about the vertex.
	 *
	 * @return Information about the vertex.
	 */
	public String displayInfo() {
		return null; // Replace with appropriate implementation
	}

} // End of Class
