
package AirFreighApp;

import GraphFramework.Vertex;

public class Location extends Vertex {

	// Data Fields
	private String routerName;

	public Location(int label) {
		super(label);
		this.routerName = String.valueOf((char) (label + 65));
	}

	// Methods
	@Override
	public String displayInfo() {

		return "loc." + routerName + ": city " + label;

	}

} // End of class
