
package AirFreighApp;

import GraphFramework.Edge;
import GraphFramework.Vertex;


public class Route extends Edge {

	public Route(Vertex source, Vertex target, int weight) {
		super(source, target, weight);
	} // End of Method

	public void displayInfo() {

	} // End of Method

} // End of Class
