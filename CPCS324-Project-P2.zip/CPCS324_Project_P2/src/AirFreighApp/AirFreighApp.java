package AirFreighApp;

import GraphFramework.DBAllSourceSPAlg;
import GraphFramework.SingleSourceSPAlg;
import GraphFramework.Graph;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class AirFreighApp extends AFRouteMap {
	public static void main(String[] args) throws FileNotFoundException {
		int verticesNO = 0;
		int edgesNO = 0;
		boolean isDigraph = false;

		System.out.println("*** Press 1 for Requirement 1 Using Read_from_Graph Func.");
		System.out.println("*** Press 2 for Requirement 2 Using Make_Graph Func. ");

		// Read User Input
		Scanner input = new Scanner(System.in);
		System.out.print("Choose Option: ");
//		int userInput = 0;
		int userInput = input.nextInt();

		// Verifying user input
		while (userInput != 1 && userInput != 2 ) {
			System.out.println("Wrong Selection. ");
			System.out.print("Choose again: ");
			userInput = input.nextInt();
		}

		// Requirement 1
		if (userInput == 1) {
			File graphFile = new File("graph.txt"); // Read from File
			Graph graph = new Graph(); // Create An Object of Graph as graph
			graph.readGraphFromFile(graphFile); // Access readGraphFromFile Method in Graph Class

			SingleSourceSPAlg dijkstra = new SingleSourceSPAlg(graph);
			dijkstra.computeDijkstraAlg(graph); // Read Graph in Dijkstra Algorithm
			dijkstra.printResult(); // Print path list and router length
		} else if (userInput == 2) {
			System.out.print("\nMake direct graph? Press y/n! "); // Ask user if he/she wants to do the algorithm with direct graph
			String choiceDigraph = input.next();

			// FOR WRONG INPUT
			while (!choiceDigraph.equalsIgnoreCase("y") && !choiceDigraph.equalsIgnoreCase("n")) {
				System.out.println("\n---- Invalid input! ----");
				System.out.print("> Enter your choice again: ");
				choiceDigraph = input.next();
			}

			// If the user's answer was yes, make a directed graph
			if (choiceDigraph.equalsIgnoreCase("y")) {
				isDigraph = true;
			}

			System.out.println("\n 1-  Vertices = 2000 , Edges = 10000");
			System.out.println(" 2-  Vertices = 3000 , Edges = 15000");
			System.out.println(" 3-  Vertices = 4000 , Edges = 20000");
			System.out.println(" 4-  Vertices = 5000 , Edges = 25000");
			System.out.println(" 5-  Vertices = 6000 , Edges = 30000");

			// Read User Input for the Selected Case
			System.out.print("\nSelect any Option to test: ");
			userInput = input.nextInt(); // Option of the Case

			while (userInput > 5 || userInput < 1) {
				System.out.println("Option not found.");
				System.out.print("Select your Test Option again: ");
				userInput = input.nextInt();
			}
			int[] ans = userInput(userInput);
			verticesNO = ans[0];
			edgesNO = ans[1];

			Graph graph = new Graph(verticesNO, edgesNO, isDigraph); // Create An Object of Graph as networkTopology
			graph.makeGraph(verticesNO, edgesNO); // Access makeGraph Method in Graph Class
			SingleSourceSPAlg dijkstra = new SingleSourceSPAlg(graph); // Create DijkstraAlg object to use Dijkstra algorithm
			long startTime = System.currentTimeMillis(); // Store the time before invoking the algorithm
			dijkstra.computeDijkstraAlg(graph);
			long finishTime = System.currentTimeMillis(); // Store the time after invoking the algorithm

			// Print the running time
			System.out.println("\nRuntime for Dijkstra algorithm is: " + (finishTime - startTime) + " ms \n");
		} 
		input.close();
	}

	// Helper method to get user input for vertices and edges
	private static int[] userInput(int num) {
		int vertices = 0;
		int edges = 0;
		switch (num) {
			case 1:
				vertices = 2000;
				edges = 10000;
				break;
			case 2:
				vertices = 3000;
				edges = 15000;
				break;
			case 3:
				vertices = 4000;
				edges = 20000;
				break;
			case 4:
				vertices = 5000;
				edges = 25000;
				break;
			case 5:
				vertices = 6000;
				edges = 30000;
				break;
		}
		return new int[]{vertices, edges};
	}

}
